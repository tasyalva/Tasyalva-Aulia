x = float(input('Masukkan angka ke-1 = '))
y = float(input('Masukkan angka ke-2 = '))
z = float(input('Masukkan angka ke-3 = '))

if x==y==z:
    print("Segitiga ini Segitiga Sama Sisi")
elif (x or y or z <= 0) and (x >= (x+y)) or (y >= x+z) or (z >= x+y):
    print("Segitiga ini tidak dapat dibangun")
elif (x==y or y==z or x==z):
    print("Segitiga ini Segitiga Sama Kaki")
elif (x*x == y*y + z*z or y*y == x*x + z*z or z*z == y*y + x*x):
    print("Segitiga ini Segitiga Siku-Siku")
else :
    print("SEGITIGA BEBAS")
